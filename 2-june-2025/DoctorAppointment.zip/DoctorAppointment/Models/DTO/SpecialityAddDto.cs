namespace DoctorAppointment.Models
{
    public class SpecialityAddDto
    {
        public string Name { get; set; } = string.Empty;
    }
}